package com.reqlclient.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ReqlScreen extends Screen {
    private static final int PANEL = 0xF0181A23;
    private static final int ACCENT = 0xFF8B5CF6;
    private static final int TEXT = 0xFFF5F5FA;
    private static final int MUTED = 0xFF9DA3B4;

    private static final List<String> CATEGORIES =
            List.of("Combat", "Movement", "HUD", "Visuals", "Settings");

    private final Map<String, List<String>> modules = new LinkedHashMap<>();
    private final Map<String, Boolean> states = new LinkedHashMap<>();
    private String category = "Combat";
    private String selectedModule = "";
    private boolean mobsOnly = true;

    public ReqlScreen() {
        super(Component.literal("Reql Client"));
        modules.put("Combat", List.of("Aim Assist", "Trigger Bot", "HitCrystal", "AnchorSafe", "AutoTotem", "MOBS"));
        modules.put("Movement", List.of("Parkour", "Sprint"));
        modules.put("HUD", List.of("Boost FPS", "FPS Counter", "FPS Viewers", "Enemies"));
        modules.put("Visuals", List.of("Low Fire", "Low Shield", "Low Totem", "Nether Fog", "Water Fog", "Player ESP", "Xray"));
        modules.put("Settings", List.of("Menu Animation", "Accent Color", "Reset Layout"));
        for (List<String> names : modules.values()) {
            for (String name : names) states.put(name, false);
        }
    }

    @Override
    protected void init() {
        clearWidgets();
        int panelLeft = Math.max(12, (width - 700) / 2);
        int panelTop = Math.max(12, (height - 430) / 2);
        int navY = panelTop + 76;

        for (int i = 0; i < CATEGORIES.size(); i++) {
            String item = CATEGORIES.get(i);
            int x = panelLeft + 22 + i * 130;
            addRenderableWidget(Button.builder(Component.literal(item), button -> {
                category = item;
                selectedModule = "";
                rebuild();
            }).bounds(x, navY, 120, 28).build());
        }

        List<String> entries = modules.getOrDefault(category, List.of());
        for (int i = 0; i < entries.size(); i++) {
            String module = entries.get(i);
            int y = navY + 52 + i * 42;
            if (y > panelTop + 360) break;
            String label = module.equals("MOBS")
                    ? "MOBS: " + (mobsOnly ? "ON" : "OFF")
                    : (Boolean.TRUE.equals(states.get(module)) ? "●  " : "○  ") + module;
            addRenderableWidget(Button.builder(Component.literal(label), button -> {
                if (module.equals("MOBS")) {
                    mobsOnly = !mobsOnly;
                } else {
                    states.put(module, !Boolean.TRUE.equals(states.get(module)));
                    selectedModule = module;
                }
                rebuild();
            }).bounds(panelLeft + 24, y, 390, 34).build());
        }

        addRenderableWidget(Button.builder(Component.literal("CERRAR"), button -> onClose())
                .bounds(panelLeft + 24, panelTop + 382, 130, 28).build());
    }

    private void rebuild() {
        init();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0x99000000);
        int x = (width - 700) / 2;
        int y = (height - 430) / 2;
        graphics.fill(x + 6, y + 8, x + 706, y + 438, 0x66000000);
        graphics.fill(x, y, x + 700, y + 430, PANEL);
        graphics.fill(x, y, x + 700, y + 5, ACCENT);
        graphics.text(font, "REQL CLIENT", x + 24, y + 20, TEXT, false);
        graphics.text(font, "MINECRAFT 26.3  •  FABRIC", x + 24, y + 39, MUTED, false);
        graphics.text(font, "CATEGORY: " + category.toUpperCase(), x + 24, y + 119, ACCENT, false);
        graphics.text(font, "Target mode: " + (mobsOnly ? "MOBS" : "MANUAL / DISABLED"), x + 440, y + 119, TEXT, false);

        if (!selectedModule.isEmpty()) {
            graphics.fill(x + 440, y + 160, x + 676, y + 330, 0xFF242735);
            graphics.text(font, "MODULE", x + 456, y + 177, ACCENT, false);
            graphics.text(font, selectedModule, x + 456, y + 198, TEXT, false);
            graphics.text(font, "UI state: " + (Boolean.TRUE.equals(states.get(selectedModule)) ? "ON" : "OFF"),
                    x + 456, y + 222, TEXT, false);
            graphics.text(font, "Detailed module settings", x + 456, y + 252, MUTED, false);
            graphics.text(font, "will be added in later builds.", x + 456, y + 266, MUTED, false);
        }
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (minecraft != null && minecraft.gui.screen() == this) {
            minecraft.gui.setScreen(null);
        }
    }
}
