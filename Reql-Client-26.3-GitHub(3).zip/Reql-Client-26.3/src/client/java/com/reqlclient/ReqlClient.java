package com.reqlclient;

import com.mojang.blaze3d.platform.InputConstants;
import com.reqlclient.gui.ReqlScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class ReqlClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("reqlclient", "main"));

    private static KeyMapping openLeftShift;
    private static KeyMapping openRightShift;

    @Override
    public void onInitializeClient() {
        openLeftShift = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.reqlclient.open_left_shift",
                InputConstants.Type.KEYBOARD,
                InputConstants.KEY_LSHIFT,
                CATEGORY
        ));

        openRightShift = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.reqlclient.open_right_shift",
                InputConstants.Type.KEYBOARD,
                InputConstants.KEY_RSHIFT,
                CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean pressed = false;
            while (openLeftShift.consumeClick()) pressed = true;
            while (openRightShift.consumeClick()) pressed = true;

            if (pressed && client.player != null && !(client.gui.screen() instanceof ReqlScreen)) {
                client.gui.setScreen(new ReqlScreen());
            }
        });
    }
}
