# Reql Client 0.2.1 — Minecraft Java 26.3

Fabric client mod project.

## Toolchain
- Minecraft 26.3
- Java 25
- Fabric Loader 0.20.1
- Fabric API 0.167.0+26.3
- Fabric Loom 1.19-SNAPSHOT
- Gradle 9.8.1 (GitHub Actions)

## Current build contents
- Reql Client dark GUI.
- Left Shift and Right Shift registered separately to open the menu.
- Categories: Combat, Movement, HUD, Visuals, Settings.
- MOBS target-mode toggle in the GUI.
- Module list and per-module enabled UI state.
- Source is split into Fabric client source set.

## Scope
The MOBS switch and module toggles in this starter are configuration/UI state only. They do not yet perform combat actions or alter entity behaviour. The project README deliberately distinguishes implemented UI from planned gameplay modules.

## Build
Run `gradle build` with Java 25. GitHub Actions workflow is in `.github/workflows/build.yml`.
