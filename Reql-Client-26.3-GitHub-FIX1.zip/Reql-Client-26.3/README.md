# Reql Client 26.3

Starter Fabric client-mod project for Minecraft Java 26.3.

## Build

GitHub Actions runs automatically on pushes to `main`/`master`, pull requests, or manually through **Actions → Build Reql Client 26.3 → Run workflow**.

The build artifact is named `Reql-Client-26.3`.

## Toolchain

- Minecraft Java: 26.3
- Java: 25
- Fabric Loader: 0.20.1
- Fabric API: 0.166.0+26.3
- Fabric Loom: 1.19-SNAPSHOT
- Gradle: 9.6.0

Versions are aligned with the Fabric 26.3 example/development references available when this starter was prepared.

## Current scope

This is a minimal compile-verification baseline. It only registers a client initializer and logs a startup message. It is **not yet the finished Reql Client interface or feature set**.
