package com.reqlclient;

import net.fabricmc.api.ClientModInitializer;

/**
 * Reql Client 26.3 - initial build-verification baseline.
 * This starter intentionally contains no automated combat actions.
 */
public final class ReqlClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        System.out.println("[Reql Client] Client initializer loaded for Minecraft 26.3.");
    }
}
